#!/usr/bin/env bash
# Archived on 2026-05-21.
# Current supported runtime reference recovery uses restore_runtime_reference_snapshot.php.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../../.." && pwd -P)"
SOURCE_DIR="$REPO_ROOT/original-codes/mtool_lib/dbclasses"
REFERENCE_ROOT_DIR="$REPO_ROOT/mtool/reference"
RUNTIME_REFERENCE_DIR="$REPO_ROOT/mtool/reference/dbclasses"
STAGED_RECOVERY_DIR="$REPO_ROOT/work/legacy-recovery/dbclasses"
TARGET_DIR="$STAGED_RECOVERY_DIR"
LAST_RESORT_CONFIRMED=0

normalize_path() {
  local path="$1"
  local parent_dir
  local basename_part

  if [ "$path" = "/" ]; then
    printf '/\n'
    return 0
  fi

  parent_dir="$(dirname "$path")"
  basename_part="$(basename "$path")"
  mkdir -p "$parent_dir"
  parent_dir="$(cd "$parent_dir" && pwd -P)"
  printf '%s/%s\n' "$parent_dir" "$basename_part"
}

show_runtime_reference_restore_guidance() {
  cat >&2 <<'TEXT'
authoritative runtime reference overwrite from legacy dbclasses is retired
use one of the snapshot-backed recovery paths instead:
  make restore-runtime-reference-snapshot ARTIFACT_KEY=...
  php mtool/scripts/restore_runtime_reference_snapshot.php --artifact-key=...

if you intentionally need to revive the archived staged-copy flow, run:
  bash mtool/old/bootstrap-dbclasses/bootstrap_dbclasses.sh --last-resort
TEXT
}

show_last_resort_confirmation_guidance() {
  cat >&2 <<'TEXT'
bootstrap_dbclasses.sh is an archived last-resort host-side legacy staging helper.
if you still need a quarantined writable full-tree legacy copy for host-side emergency preparation,
re-run with:
  bash mtool/old/bootstrap-dbclasses/bootstrap_dbclasses.sh --last-resort

for authoritative runtime reference repair, use:
  make restore-runtime-reference-snapshot ARTIFACT_KEY=...
  php mtool/scripts/restore_runtime_reference_snapshot.php --artifact-key=...
TEXT
}

usage() {
  cat <<'TEXT'
Usage:
  bash mtool/old/bootstrap-dbclasses/bootstrap_dbclasses.sh --last-resort
  bash mtool/old/bootstrap-dbclasses/bootstrap_dbclasses.sh --last-resort --source-dir=original-codes/mtool_lib/dbclasses
  bash mtool/old/bootstrap-dbclasses/bootstrap_dbclasses.sh --last-resort --target-dir=/path/to/staged/dbclasses

Options:
  --last-resort        acknowledge that this is an explicit legacy staging action
  --source-dir=PATH    host-side legacy dbclasses source directory
  --target-dir=PATH    target directory for a staged recovery copy
  --help               Show this help

Notes:
  - This helper is archived under `mtool/old/bootstrap-dbclasses/`.
  - The current supported runtime reference recovery path is snapshot-backed restore.
  - The default source is `original-codes/mtool_lib/dbclasses` on the host filesystem.
  - The default target is `work/legacy-recovery/dbclasses`, which is a quarantined staged copy.
  - `--target-dir` must stay outside `mtool/reference/`.
  - The base Docker runtime does not mount `original-codes/`.
  - This helper never updates `mtool/reference/dbclasses`.
  - Restore the authoritative runtime reference with `make restore-runtime-reference-snapshot ARTIFACT_KEY=...`
    or `php mtool/scripts/restore_runtime_reference_snapshot.php --artifact-key=...`.
  - The old `--apply-to-runtime-reference` path is retired and now fails fast with that guidance.
  - Re-run with `--last-resort` only when you intentionally need a host-side staged legacy copy.
  - Use this helper only when a quarantined writable full-tree legacy copy is still required for
    host-side emergency preparation outside the authoritative runtime reference.
TEXT
}

for argument in "$@"; do
  case "$argument" in
    --help|-h)
      usage
      exit 0
      ;;
    --last-resort)
      LAST_RESORT_CONFIRMED=1
      ;;
    --source-dir=*)
      SOURCE_DIR="${argument#--source-dir=}"
      ;;
    --target-dir=*)
      TARGET_DIR="${argument#--target-dir=}"
      ;;
    --apply-to-runtime-reference)
      show_runtime_reference_restore_guidance
      exit 1
      ;;
    *)
      echo "unsupported argument: $argument" >&2
      usage >&2
      exit 1
      ;;
  esac
done

if [ "$LAST_RESORT_CONFIRMED" != "1" ]; then
  show_last_resort_confirmation_guidance
  exit 1
fi

if [ "${SOURCE_DIR#/}" = "$SOURCE_DIR" ]; then
  SOURCE_DIR="$REPO_ROOT/$SOURCE_DIR"
fi

if [ "${TARGET_DIR#/}" = "$TARGET_DIR" ]; then
  TARGET_DIR="$REPO_ROOT/$TARGET_DIR"
fi

SOURCE_DIR="$(normalize_path "$SOURCE_DIR")"
REFERENCE_ROOT_DIR="$(normalize_path "$REFERENCE_ROOT_DIR")"
RUNTIME_REFERENCE_DIR="$(normalize_path "$RUNTIME_REFERENCE_DIR")"
STAGED_RECOVERY_DIR="$(normalize_path "$STAGED_RECOVERY_DIR")"
TARGET_DIR="$(normalize_path "$TARGET_DIR")"

if [ ! -d "$SOURCE_DIR" ]; then
  echo "source directory not found: $SOURCE_DIR" >&2
  exit 1
fi

if [ "$TARGET_DIR" = "/" ] || [ "$TARGET_DIR" = "" ]; then
  echo "refusing unsafe target directory: $TARGET_DIR" >&2
  exit 1
fi

case "$TARGET_DIR" in
  "$SOURCE_DIR"|"$SOURCE_DIR"/*)
    echo "refusing target directory inside legacy source tree: $TARGET_DIR" >&2
    exit 1
    ;;
  "$REFERENCE_ROOT_DIR"|"$REFERENCE_ROOT_DIR"/*)
    echo "refusing target directory under durable reference root: $TARGET_DIR" >&2
    show_runtime_reference_restore_guidance
    exit 1
    ;;
esac

if [ "$TARGET_DIR" = "$REPO_ROOT" ]; then
  echo "refusing unsafe target directory: $TARGET_DIR" >&2
  exit 1
fi

rm -rf "$TARGET_DIR"
mkdir -p "$(dirname "$TARGET_DIR")"
cp -R "$SOURCE_DIR" "$TARGET_DIR"

data_count="$(find "$TARGET_DIR" -maxdepth 1 -type f -name 'data-*.php' | wc -l | tr -d ' ')"
dbaccess_count="$(find "$TARGET_DIR" -maxdepth 1 -type f -name 'dbaccess-*.php' | wc -l | tr -d ' ')"
total_count="$(find "$TARGET_DIR" -maxdepth 1 -type f | wc -l | tr -d ' ')"

echo "legacy dbclasses recovery completed"
echo "  mode: archived host-side quarantined full-tree legacy copy"
echo "  acknowledged_last_resort: yes"
echo "  source: $SOURCE_DIR"
echo "  target: $TARGET_DIR"
echo "  authoritative_runtime_reference: $RUNTIME_REFERENCE_DIR"
echo "  default_staged_recovery_target: $STAGED_RECOVERY_DIR"
echo "  total: $total_count"
echo "  data: $data_count"
echo "  dbaccess: $dbaccess_count"
