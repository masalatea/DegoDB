# bootstrap-dbclasses archive

- `bootstrap_dbclasses.sh` は 2026-05-21 に current mainline helper から外し、この directory に archive した。
- current supported runtime reference repair / rollback は `make restore-runtime-reference-snapshot ARTIFACT_KEY=...` または `php mtool/scripts/restore_runtime_reference_snapshot.php --artifact-key=...` を使う。
- current `Makefile` はこの helper を通常導線では呼ばない。
- host-side quarantined full-tree legacy copy が本当に必要になった時だけ、この archive から明示的に復帰させて使う。
