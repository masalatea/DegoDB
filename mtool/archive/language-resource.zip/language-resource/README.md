# LanguageResource Legacy Overlay Archive

- ここには `LanguageResource` 旧 overlay compose / seed pack の archive を置く。
- current `MTOOL` runtime / generator / test の通常導線からは参照しない。
- 必要な場合だけ、archive を明示的に展開して migration/debug 用に使う。

Current archive policy:

- `legacy-overlay-2026-0518.tar.gz`
  - former `mtool/docker/compose/02_mtool_language_resource.compose.yaml`
  - former `mtool/docker/mariadb/config-seed-language-resource/`
