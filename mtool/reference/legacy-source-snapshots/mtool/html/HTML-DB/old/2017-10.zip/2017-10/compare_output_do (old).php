<?php
require '/home/matsue/composer/vendor/autoload.php';

$base_dir = __DIR__ . "/";
$MAX_INCLUDE_CONFIG_TRY = 10;
for($try_index = 0 ; $try_index <= $MAX_INCLUDE_CONFIG_TRY ; $try_index++) {
	$site_configfile = $base_dir . "config.php";
	if (is_file($site_configfile)) {
		include_once($site_configfile);
		break;
	}
	$base_dir .= "../";
}
include_once("/home/matsue/www/mtool_lib/lib_commonheader.php");
include_once("/home/matsue/www/mtool_lib/dbclasses/autoload_mtool.php");
include_once("/home/matsue/www/mtool_lib/lib_mtool_db.php");
include_once("/home/matsue/www/mtool_lib/lib_path_on_top.php");
?>
<!DOCTYPE HTML>
<html><!-- InstanceBegin template="/Templates/UserOnly.dwt.php" codeOutsideHTMLIsLocked="true" --><head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- InstanceBeginEditable name="doctitle" -->
<title><?php print getres("TITLE_PROJECT_SOURCE_COMPARE_EXECUTE"); ?> - <?php print getres("TITLE_TOP"); ?></title>
<!-- InstanceEndEditable -->
<?php
include_once("/home/matsue/www/$WWWDOMAINNAME/topmenu_include.php");
include_once("/home/matsue/www/$WWWDOMAINNAME/hreflang_include.php");
include_once("/home/matsue/www/$WWWDOMAINNAME/common_html_header_top.php");
?>
<script src="/js/jquery.periodicalupdater.js"></script>



<!-- InstanceBeginEditable name="head" -->
<!-- InstanceEndEditable -->



</head>

<body>
<?php
include_once("/home/matsue/www/$WWWDOMAINNAME/common_html_body_script.php");
include_once("/home/matsue/www/mtool_lib/topmenu_include_navbar.php");
include_once("/home/matsue/www/mtool_lib/channel_header.php");
include_once("/home/matsue/www/nodejs_lib/commonheader_check_whiteboard_update.php");
include_once("/home/matsue/www/$WWWDOMAINNAME/tawkto_common_include.php");
?>
<div class="container-fluid" id="container-fluid-body">


<?php
include_once("/home/matsue/www/mtool_lib/login_lib_jump_body.php");
?>

<?php
if ($matsuesoft_login_user_email_verified == false) {
	?>
	<h3><?php print getres("NOTICE_PLEAE_AUTHENTICATE_EMAIL_BEFORE_USE"); ?></h3>
	<?php

	include_once("/home/matsue/www/mtool_lib/email_verification_include.php");

	show_message_about_email_verification(true);

} else {
	?>
	
	<?php
	$ProjectPID = trim(GetParam("ProjectPID"));
	if (CheckIfLoginUserIsUserAndOutputMessage($ProjectPID, $matsuesoft_login_token_id)) {
	?>
	<!-- InstanceBeginEditable name="body_user_only" -->

<?php
include_once("/home/matsue/www/mtool_lib/lib_form.php");
include_once("/home/matsue/www/mtool_lib/lib_mtool_dropbox_core.php");
include_once("/home/matsue/www/mtool_lib/lib_mtool_dropbox.php");
include_once("/home/matsue/www/mtool_lib/lib_mtool_compare_output.php");
include_once("/home/matsue/www/mtool_lib/lib_mtool_ignore.php");
include_once("/home/matsue/www/mtool_lib/lib_mtool_build.php");
include_once("/home/matsue/www/mtool_lib/lib_mtool_compare_output.php");

$FORCE_CHECK_UPDATED_DAY_THRESHOLD = 3;
$SHOW_DEBUG = false;

$START_CHECK = (trim(GetParam("START_CHECK")) != "");
$ProjectPID = trim(GetParam("ProjectPID"));
$QUICK_CHECK = trim(GetParam("QUICK_CHECK"));
$QUICK_CHECK_THRESHOLD_DAY = trim(GetParam("QUICK_CHECK_THRESHOLD_DAY"));
if (!is_numeric($QUICK_CHECK_THRESHOLD_DAY)) {
	$QUICK_CHECK_THRESHOLD_DAY = $FORCE_CHECK_UPDATED_DAY_THRESHOLD;
}

$CheckTargetProjectPIDList = GetParam("CheckTargetProjectPIDList");
if (!is_array($CheckTargetProjectPIDList)) {
	$CheckTargetProjectPIDList = array();
}

$is_first = !$START_CHECK;

if ($is_first) {
	$QUICK_CHECK = "y";
}

$NoError = true;
if (!is_numeric($ProjectPID)) {
	?>
    <H3><font color="red">ERROR! Unknown Project PID</font></H3>
    <?php
	$NoError = false;
}

$COMPARE_OUTPUT_TEMPLATE_FOR_TEXT                = "compare_output_template_for_text.txt";
$COMPARE_OUTPUT_TEMPLATE_FOR_TEXT_LINE           = "compare_output_template_for_text_line.txt";
$COMPARE_OUTPUT_TEMPLATE_FOR_WINDOWS_BATCH       = "compare_output_template_for_windows_batch.txt";
$COMPARE_OUTPUT_TEMPLATE_FOR_WINDOWS_BATCH_LINE  = "compare_output_template_for_windows_batch_line.txt";
$COMPARE_OUTPUT_TEMPLATE_FOR_MAC_COMMAND         = "compare_output_template_for_mac_command.txt";
$COMPARE_OUTPUT_TEMPLATE_FOR_MAC_COMMAND_LINE    = "compare_output_template_for_mac_command_line.txt";

$IgnoreDirSettingFile  = "compare_ignore_dir_setting_regex.txt";
$IgnoreDirSettingFileSettingList = InitializeIgnoreSettingFileSettingListSub($IgnoreDirSettingFile);

function check_all_dropbox_folder_continuously($CompareOutput, $DropboxAccessToken, $DropboxBaseFolderPath, $dropboxPath, &$ContentList)
{
	global $IgnoreDirSettingFileSettingList;
	global $QUICK_CHECK;
	global $QUICK_CHECK_THRESHOLD_DAY;
	
	// $DropboxFullPath = pathCombine($DropboxBaseFolderPath, $dropboxPath);
	$DropboxFullPath = $dropboxPath;
	print "$DropboxFullPath";
	
	if (CheckIgnoreDirForUploadFileSettingListForOne($IgnoreDirSettingFileSettingList, $dropboxPath)) {
		// Skip
		print " -&gt; Skip\n";
		return;
	}
	
	$DACompareOutputSearchCache = new CompareOutputSearchCacheDBAccess();
	$meta_data_list = array();
	
	$load_from_dropbox_server = false;
	if ($QUICK_CHECK != "") {
		$CompareOutputSearchCacheList = $DACompareOutputSearchCache->GetCompareOutputSearchCacheList($CompareOutput->PID, $CompareOutput->ProjectPID, $CompareOutput->DropboxBaseFolderPID, $DropboxAccessToken, $DropboxBaseFolderPath, $DropboxFullPath);
		for($i = 0 ; $i < count($CompareOutputSearchCacheList); $i++) {
			$CompareOutputSearchCache = $CompareOutputSearchCacheList[$i];
			$thisContent = new DropboxAPIMetaData($CompareOutputSearchCache->Result_DropboxBaseFolder, json_decode($CompareOutputSearchCache->Result_MetaData, true));
			
			array_push($meta_data_list, $thisContent);
			
			if ($thisContent->IsFile) {
				// print_r($CompareOutputSearchCache);
				// print_r($thisContent);
				
				$this_server_modified = GetHashValue($thisContent->OriginalMetaData, "server_modified");
				$t_server_modified = strtotime($this_server_modified);
				
				if ($t_server_modified > 0) {
					$date_server_modified = date("Y/n/j G:i:s", $t_server_modified);
					// print $this_server_modified . " ------- " . $date_server_modified . "\n";
					
					if (time() - $t_server_modified < (60 * 60 * 24 * $QUICK_CHECK_THRESHOLD_DAY)) {
						// recently updated
						$load_from_dropbox_server = true;
					}
					
				} else {
					print "Internal Error! Failed to parse Date Time Text: " . $this_server_modified . "\n";
				}
			}
		}
	} else {
		$load_from_dropbox_server = true;
	}
	if ($load_from_dropbox_server) {
		print " <font color=green>Loading...</font>";
		// print " load from dropbox server\n";
		$meta_data_list = GetAllDropboxListFolderContinuously($DropboxAccessToken, $DropboxBaseFolderPath, $DropboxFullPath);
		
		$CompareOutputSearchCacheObj = new CompareOutputSearchCacheData();
		$CompareOutputSearchCacheObj->CompareOutputPID = $CompareOutput->PID;
		$CompareOutputSearchCacheObj->ProjectPID = $CompareOutput->ProjectPID;
		$CompareOutputSearchCacheObj->DropboxBaseFolderPID = $CompareOutput->DropboxBaseFolderPID;
		$CompareOutputSearchCacheObj->SearchKey_DropboxAccessToken = $DropboxAccessToken;
		$CompareOutputSearchCacheObj->SearchKey_DropboxBaseFolderPath = $DropboxBaseFolderPath;
		$CompareOutputSearchCacheObj->SearchKey_DropboxFullPath = $DropboxFullPath;
		$DACompareOutputSearchCache->DeleteCompareOutputSearchCache($CompareOutputSearchCacheObj);
		
		for($k = 0 ; $k < count($meta_data_list); $k++) {
			$thisContent = $meta_data_list[$k];
			// print_r($thisContent);
			
			$CompareOutputSearchCacheObj->Result_MetaData = json_encode($thisContent->OriginalMetaData);
			$CompareOutputSearchCacheObj->Result_DropboxBaseFolder = $thisContent->OriginalDropboxBaseFolder;
			$DACompareOutputSearchCache->InsertCompareOutputSearchCache($CompareOutputSearchCacheObj);
		}
	} else {
		print " (use Cache)";
	}
	print "\n";
	
	for($k = 0 ; $k < count($meta_data_list); $k++) {
		$thisContent = $meta_data_list[$k];
		// print_r($thisContent);
		
		array_push($ContentList, $thisContent);
		
		if ($thisContent->IsDir) {
			// Dir
			// print_r($thisContent);
			// print "\n";
			
			// $NextDropboxFullPath = pathCombine($DropboxFullPath, $thisContent->PathDisplay);
			
			check_all_dropbox_folder_continuously($CompareOutput, $DropboxAccessToken, $DropboxBaseFolderPath, $thisContent->PathDisplay, $ContentList);
		} else {
			// print_r($thisContent);
			// print "\n";
		}
	}
}
function GetCorrespondingContentForMtool($ContentList, $searchPath)
{
	for($k = 0 ; $k < count($ContentList); $k++) {
		$thisContent = $ContentList[$k];
		
		if (strtoupper($thisContent->PathDisplay) == strtoupper($searchPath)) {
			return $thisContent;
		}
	}
	return NULL;
}

function compare_folder_on_dropbox($ContentList, $baseFolderContent, $baseCorrespondingFolderContent)
{
	global $SHOW_DEBUG;
	
	$ThereIsDeviation = false;
	
	if ($baseFolderContent->IsDir && $baseCorrespondingFolderContent->IsDir) {
		
		print "Comparing Folder: $baseFolderContent->PathDisplay and $baseCorrespondingFolderContent->PathDisplay\n";
		
		for($k = 0 ; $k < count($ContentList); $k++) {
			$thisContent = $ContentList[$k];
			
			if ($SHOW_DEBUG) {
				print_r($thisContent);
			}
			
			if (startsWith(strtoupper($thisContent->PathDisplay), strtoupper($baseFolderContent->PathDisplay)) &&
			    $thisContent->PathDisplay != $baseFolderContent->PathDisplay)
			{
				$correspondingFilePath = substr_replace($thisContent->PathDisplay, $baseCorrespondingFolderContent->PathDisplay, 0, strlen($baseFolderContent->PathDisplay));
				
				if ($thisContent->PathDisplay == $correspondingFilePath) {
					$error_message = "Internal Error! Something Wrong... Failed to make Corresponding File Path.";
					print "$error_message\n";
					die($error_message);
				}

				$correspondingContent = GetCorrespondingContentForMtool($ContentList, $correspondingFilePath);
				if ($correspondingContent) {
					
					if ($SHOW_DEBUG) {
						print_r($correspondingContent);
					}
					
					if ($thisContent->IsFile)
					{
						$this_content_hash = GetHashValue($thisContent->OriginalMetaData, "content_hash");
						$corresponding_content_hash = GetHashValue($correspondingContent->OriginalMetaData, "content_hash");
						if ($this_content_hash && $this_content_hash != "" && $this_content_hash == $corresponding_content_hash) {
							// Same
						} else {
							// Different
							print "Not Match: $thisContent->PathDisplay and $correspondingFilePath\n";
							$ThereIsDeviation = true;
						}
					}
					else if ($thisContent->IsDir)
					{
						// print_r($thisContent);
						$thisThereIsDeviation = compare_folder_on_dropbox($ContentList, $thisContent, $correspondingContent);
						$ThereIsDeviation = $ThereIsDeviation | $thisThereIsDeviation;
					}
					
				} else {
					if ($thisContent->IsFile) {
						print "Corresponding file is not exist: $thisContent->PathDisplay -&gt; $correspondingFilePath not found\n";
						$ThereIsDeviation = true;
					}
					else if ($thisContent->IsDir)
					{
						// no warning
					}
				}
			}
		}
	}
	return $ThereIsDeviation;
}

$TMP_OUTPUT_REGEX_PATTERN = "/\s*-\s*tmp\s*output\s*$/i";
function CheckIfTmpOutputDirForMtool($path)
{
	global $TMP_OUTPUT_REGEX_PATTERN;
	return preg_match($TMP_OUTPUT_REGEX_PATTERN, $path);
}
function RemoveTmpOutputDirSuffixForMtool($path)
{
	global $TMP_OUTPUT_REGEX_PATTERN;
	return preg_replace($TMP_OUTPUT_REGEX_PATTERN, "", $path);
}

class DeviationFolderInfo
{
	public $PathA;
	public $PathB;
    function DeviationFolderInfo($path_a, $path_b)
    {
		$this->PathA = $path_a;
		$this->PathB = $path_b;
    }
}

if ($NoError) {
	$DBWritePermission = CheckIfPossibleToAccess($ProjectPID, $matsuesoft_login_token_id, ProjectUserSerurityEnum::$DBTOOLWRITE);
	$IsMtoolProjectOwner = CheckIfMtoolProjectOwner($ProjectPID, $matsuesoft_login_token_id);
	
	printPathOnTopForSourceCompare("Compare Output", $ProjectPID);
	
	$DAProject = new ProjectDBAccess();
	$projectlist = $DAProject->GetProjectbyOwnerOrUserSecurityList($matsuesoft_login_token_id); 
	
	if (count($projectlist) > 0) {
		?>
<script>
$(function(){
	<?php
	if ($START_CHECK) {
		?>
		$('#buildingactivity_upper').activity(true);
		$('#buildingactivity_bottom').activity(true);
		<?php
	} else {
		?>
		$("#comppareoutputform").show();
		<?php
	}
	?>
});
</script>
		<div id="buildingactivity_upper"></div>
        <form id="comppareoutputform" action="<?php print $_SERVER['SCRIPT_NAME']; ?>" method="post" style="display:none">
       <br>
        <p>
			<input name="ProjectPID" type="hidden" value="<?php print htmlspecialchars($ProjectPID); ?>">
			<input name="START_CHECK" id="START_CHECK" value="Start Check" type="submit">
		</p>
		<p>
		<span class="checkbox"><label><input name="QUICK_CHECK" type="checkbox" id="QUICK_CHECK"<?php if ($QUICK_CHECK != "") { print " checked"; } ?>> Quick Check</label>  Threshold: <input name="QUICK_CHECK_THRESHOLD_DAY" type="text" value="<?php print htmlspecialchars($QUICK_CHECK_THRESHOLD_DAY); ?>" size="3"> Day(s)
        </p>
		<table class="table">
			<thead>
			<tr bgcolor="#ECECEC">
			  <th>Name</th>
			  <th>Target? <span class="checkbox"><label><?php mtool_output_checkbox_for_select_all_by_name("AllCheckTarget"); ?>Check Target</label></th>
			  <th></th>
			</tr>
			</thead>
			<tbody>
		<?php
		
		function show_project_row($project, $is_main_target)
		{
			global $is_first;
			global $CheckTargetProjectPIDList;
			?>
			<tr>
				<td><?php print htmlspecialchars($project->name);
					if ($is_main_target) {
						?>
						<br>
						<font color="red">(Main Target)</font>
						<?php
					}
					?></td>
				<td><span class="checkbox"><label><input name="CheckTargetProjectPIDList[]" type="checkbox" <?php mtool_output_class_tag_for_each_checkbox_by_name("MtoolMultiCheckBoxForCheckTarget"); ?> value="<?php print $project->PID; ?>"<?php if (($is_main_target && $is_first) || in_array($project->PID, $CheckTargetProjectPIDList)) { print " checked"; } ?>>Compare</label></span></td>
			</tr>
			<?php
		}
		
		for($i = 0 ; $i < count($projectlist); $i++) {
			$project = $projectlist[$i];
			
			if ($project->PID == $ProjectPID) {
				show_project_row($project, true);
			}
		}
		for($i = 0 ; $i < count($projectlist); $i++) {
			$project = $projectlist[$i];
			
			if ($project->PID != $ProjectPID) {
				show_project_row($project, false);
			}
		}
		?>
			</tbody>
	    </table>
        </form>
		<?php
		mtool_output_script_tag_for_multi_checkbox_by_name("AllCheckTarget", "MtoolMultiCheckBoxForCheckTarget");

	} else {
		?>
    <p>none</p>
		<?php
	}
	
	if ($START_CHECK) {
		?>
		<h2>Compareing...</h2>
		<?php
		for($i = 0 ; $i < count($projectlist); $i++) {
			$project = $projectlist[$i];
			
			$is_check_target = false;
			for($j = 0 ; $j < count($CheckTargetProjectPIDList) ; $j++) {
				$CheckTargetProjectPID = $CheckTargetProjectPIDList[$j];
				if ($project->PID == $CheckTargetProjectPID) {
					$is_check_target = true;
					break;
				}
			}
			if ($is_check_target) {
				?>
				<h3>Checking for Project: <?php print htmlspecialchars($project->name); ?></h3>
				<?php
				$DACompareOutput = new CompareOutputDBAccess();
				$CompareOutputList = $DACompareOutput->GetCompareOutputList($project->PID);
				
				for($j = 0 ; $j < count($CompareOutputList) ; $j++) {
					$CompareOutput = $CompareOutputList[$j];
					
					$DropboxBaseFolder = initialize_compare_output($project->PID, $CompareOutput->DropboxBaseFolderPID, $matsuesoft_login_token_id);
					if ($DropboxBaseFolder) {
						?>
						<h4>Dropbox Base Folder: <?php print htmlspecialchars($DropboxBaseFolder->Name); ?></h4>
						<?php
						$OutputFileFullPath = get_dropbox_folder_path_for_compare_output($DropboxBaseFolder, $CompareOutput->OutputFilePath);
						$CompareFullPath = get_dropbox_folder_path_for_compare_output($DropboxBaseFolder, $CompareOutput->ComparePath);
						
						print "<pre>";
						
						$relative_dropbox_data = GetRelativeDropboxPathBasedOnUserAndDropboxBaseFolder($DropboxBaseFolder->PID, $matsuesoft_login_token_id, $CompareOutput->ComparePath);
						if ($relative_dropbox_data) {
							
							$DropboxBaseFolderPath = MakeDropboxBaseFolder($DropboxBaseFolder->Name);
							// $DropboxFullPath = pathCombine($DropboxBaseFolderPath, $CompareOutput->ComparePath);
							
							print "Checking File List...\n";
							// print "full path: " . $relative_dropbox_data->DropboxFullPath . "\n";
							
							$ContentList = array();
							check_all_dropbox_folder_continuously($CompareOutput, $relative_dropbox_data->DropboxSetting->AccessToken, $DropboxBaseFolderPath, $relative_dropbox_data->DropboxFullPath, $ContentList);
							
							print "Check File List Done\n";
							print "\n";
							
							print "Comparing...\n";
							
							$DeviationFolderInfoList = array();
							
							for($k = 0 ; $k < count($ContentList); $k++) {
								$thisContent = $ContentList[$k];
								
								if ($thisContent->IsDir) {
									if (CheckIfTmpOutputDirForMtool($thisContent->PathDisplay)) {
										$correspondingPath = RemoveTmpOutputDirSuffixForMtool($thisContent->PathDisplay);
										$correspondingContent = GetCorrespondingContentForMtool($ContentList, $correspondingPath);
										if ($correspondingContent) {
											$ThereIsDeviation = compare_folder_on_dropbox($ContentList, $thisContent, $correspondingContent);
											if($ThereIsDeviation) {
												array_push($DeviationFolderInfoList,
															new DeviationFolderInfo($thisContent->PathRelativeDisplay, $correspondingContent->PathRelativeDisplay)
												);
											}
										}
									}
								}
							}
							
							// $SHOW_DEBUG = true;
							
							$DACompareOutputAdditionalPath = new CompareOutputAdditionalPathDBAccess();
							$CompareOutputAdditionalPathList = $DACompareOutputAdditionalPath->GetCompareOutputAdditionalPathList($CompareOutput->PID, $project->PID);
							for($k = 0 ; $k < count($CompareOutputAdditionalPathList); $k++) {
								$CompareOutputAdditionalPath = $CompareOutputAdditionalPathList[$k];
								
								$DropboxBaseFoldePIDForPathA = $DropboxBaseFolder->PID;
								if ($CompareOutputAdditionalPath->PathA_DropboxBaseFolderPID > 0) {
									$DropboxBaseFoldePIDForPathA = $CompareOutputAdditionalPath->PathA_DropboxBaseFolderPID;
								}
								$DropboxBaseFoldePIDForPathB = $DropboxBaseFolder->PID;
								if ($CompareOutputAdditionalPath->PathB_DropboxBaseFolderPID > 0) {
									$DropboxBaseFoldePIDForPathB = $CompareOutputAdditionalPath->PathB_DropboxBaseFolderPID;
								}
								
								$relative_dropbox_data_for_PathA = GetRelativeDropboxPathBasedOnUserAndDropboxBaseFolder($DropboxBaseFoldePIDForPathA, $matsuesoft_login_token_id, $CompareOutputAdditionalPath->PathA);
								$relative_dropbox_data_for_PathB = GetRelativeDropboxPathBasedOnUserAndDropboxBaseFolder($DropboxBaseFoldePIDForPathB, $matsuesoft_login_token_id, $CompareOutputAdditionalPath->PathB);
								if ($relative_dropbox_data_for_PathA && $relative_dropbox_data_for_PathB) {
									
									$ContentA = GetCorrespondingContentForMtool($ContentList, $relative_dropbox_data_for_PathA->DropboxFullPath);
									$ContentB = GetCorrespondingContentForMtool($ContentList, $relative_dropbox_data_for_PathB->DropboxFullPath);
									
									if ($ContentA && $ContentB) {
										$ThereIsDeviation = compare_folder_on_dropbox($ContentList, $ContentA, $ContentB);
										if($ThereIsDeviation) {
											// print "There is a deviation\n";
											array_push($DeviationFolderInfoList,
														new DeviationFolderInfo($ContentA->PathRelativeDisplay, $ContentB->PathRelativeDisplay)
											);
										}
										
									} else {
										if (!$ContentA) {
											print "Warning. Path Not Found: " . $relative_dropbox_data_for_PathA->DropboxFullPath . "\n";
										}
										if (!$ContentB) {
											print "Warning. Path Not Found: " . $relative_dropbox_data_for_PathB->DropboxFullPath . "\n";
										}
									}
								}
							}
							
							$template_file      = "";
							$template_line_file = "";
							
							switch($CompareOutput->OutputFileType) {
								case CompareOutputOutputFileTypeEnum::$TEXT:
									$template_file      = $COMPARE_OUTPUT_TEMPLATE_FOR_TEXT;
									$template_line_file = $COMPARE_OUTPUT_TEMPLATE_FOR_TEXT_LINE;
									break;
								case CompareOutputOutputFileTypeEnum::$WINDOWSBATCH:
									$template_file      = $COMPARE_OUTPUT_TEMPLATE_FOR_WINDOWS_BATCH;
									$template_line_file = $COMPARE_OUTPUT_TEMPLATE_FOR_WINDOWS_BATCH_LINE;
									break;
								case CompareOutputOutputFileTypeEnum::$MACCOMMAND:
									$template_file      = $COMPARE_OUTPUT_TEMPLATE_FOR_MAC_COMMAND;
									$template_line_file = $COMPARE_OUTPUT_TEMPLATE_FOR_MAC_COMMAND_LINE;
									break;
								default:
									AddMtoolErrorBuildMessage("Error! Aborted. Unknown Outputt File Type: " . $CompareOutput->OutputFileType);
									continue;
							}
							$template      = file_get_contents($template_file);
							$template_line = file_get_contents($template_line_file);
							
							$lines = "";
							for($k = 0 ; $k < count($DeviationFolderInfoList); $k++) {
								$DeviationFolderInfo = $DeviationFolderInfoList[$k];
								
								$lines .= ReplaceOutputSourceInfoByKeyValue($template_line, array(
										array("KEY"=>"__COMPARE_COMMAND__", "VALUE"=>$CompareOutput->CompareToolFilePath, "TRIMLASTSPACE"=>false, "TRIMLASTRETURN"=>false),
										array("KEY"=>"__PATH_A__", "VALUE"=>$DeviationFolderInfo->PathA, "TRIMLASTSPACE"=>false, "TRIMLASTRETURN"=>false),
										array("KEY"=>"__PATH_B__", "VALUE"=>$DeviationFolderInfo->PathB, "TRIMLASTSPACE"=>false, "TRIMLASTRETURN"=>false)
									));
							}
							$template = ReplaceOutputSourceInfoByKeyValue($template, array(
									array("KEY"=>"__LINES__", "VALUE"=>$lines, "TRIMLASTSPACE"=>false, "TRIMLASTRETURN"=>false)
								));
							
							
							$fullpath_filename = pathCombine($relative_dropbox_data->DropboxFullPath, $CompareOutput->OutputFilePath);
							
							$writemode = DropboxUploadWriteMode::$add;
							$rev = "";
							
							// Check Existin File
							$needToAddOrUpdate = true;
							$tmp_file_name = tempnam(sys_get_temp_dir(), "existingfile");
							$result = GetFileFromDropBoxByAccessTokenWithFullDropboxPath($matsuesoft_login_token_id, $relative_dropbox_data->DropboxSetting->AccessToken, $fullpath_filename, $tmp_file_name, -1, 5);
							if ($result->Success && $result->FileExist) {
								$rev = $result->Rev;
								$originalLinesOneText = file_get_contents($tmp_file_name);
								$needToAddOrUpdate = CheckIfNeedToUpdateForMultiText($originalLinesOneText, $template);
								
								if (!$needToAddOrUpdate) {
									print "File is Same. No need to update. <br>\n";
								}
								$writemode = DropboxUploadWriteMode::$update;
							}
							if ($needToAddOrUpdate) {
								// $result = $dbxClient->uploadFile($fullpath_filename, $writemode, $f);
								$result = StartDropboxUpload($relative_dropbox_data->DropboxSetting->AccessToken, $template, $fullpath_filename, $writemode, $rev);
								if ($result->Success) {
									AddCompareOutputSearchCasheHint($relative_dropbox_data->DropboxSetting->PID, $fullpath_filename);
									?><font color="red">Created: <?php print htmlspecialchars($fullpath_filename); ?></font><?php
									
									if (is_file($tmp_file_name)) {
										unlink($tmp_file_name);
									}
								} else {
									?><font color="red">Failed to create: <?php print htmlspecialchars($fullpath_filename); ?></font><?php
								}
							}
						} else {
							// No Setting
						}
						print "</pre>";
					}
				}
			}
		}
		?>
		<div id="buildingactivity_bottom"></div>
<script>
$(function(){
	$("#comppareoutputform").show();
	$('#buildingactivity_upper').activity(false);
	$('#buildingactivity_bottom').activity(false);
});
</script>
		<?php
	}
	
	?>
	<br>
	<br>
	<br>
	<p><a href="./?<?php print makeRandStr(8); ?>">Back to Project List</a></p>
	<?php

}
?>
    <!-- InstanceEndEditable -->
	<?php
	}
	?>
	
	<?php
}
?>

<?php
// ここより上の処理にはLoginが必要
?>

    
</div>

<?php
include_once("/home/matsue/www/$WWWDOMAINNAME/footer_menu_include.php");
?>

<?php
include_once("/home/matsue/www/$WWWDOMAINNAME/common_html_header_bottom.php");
?>
</body>
<!-- InstanceEnd --></html>
